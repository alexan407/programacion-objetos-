package cuentabancaria;

import javax.swing.JOptionPane;

public class CuentaBancaria {
     public static void main(String[] args) {
       Cuenta_Bancaria c1 = new Cuenta_Bancaria(2845846, "Salma", 2023, 500000, "Vacio , con base");
        Cuenta_Bancaria c2 = new Cuenta_Bancaria(8458562, "Jhon", 2016, 2000000, "Vacio , con base");
        Cuenta_Bancaria c3 = new Cuenta_Bancaria(94858984, "Eugenio", 1995, 7000000, "Vacio , con base");
 
        c1.mostrarInfo();
        c2.mostrarInfo();
        c3.mostrarInfo();
 
// Comparar saldos
        Cuenta_Bancaria.compararSaldos(c1, c2, c3);
 
        // Incrementar saldo si tienen 5 años o más
        c1.incrementarSaldo();
        c2.incrementarSaldo();
        c3.incrementarSaldo();
 
        try {
            String titular = JOptionPane.showInputDialog("Ingrese Nombre del Titular");
            int ncuenta = Integer.parseInt(JOptionPane.showInputDialog("Ingrese No Cuenta"));
            int año = Integer.parseInt(JOptionPane.showInputDialog("Ingrese Año de Creación"));
            double saldo = Double.parseDouble(JOptionPane.showInputDialog("Ingrese Saldo inicial"));
            String estado = JOptionPane.showInputDialog("Ingrese Estado de la cuenta");
 
            Cuenta_Bancaria nuevaCuenta = new Cuenta_Bancaria(ncuenta, titular, año, saldo, estado);
            nuevaCuenta.mostrarInfo();
 
            // También se revisa el incremento en la nueva cuenta
            nuevaCuenta.incrementarSaldo();
 
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: debe ingresar un número válido en No Cuenta, Año o Saldo.");
        }
       //Llamamos el metodo retirar dinero
        int monto = Integer.parseInt(JOptionPane.showInputDialog(
                "Ingrese monto a retirar de la cuenta de " + c1.Titular_cuenta));
        c1.sacarDinero(monto);
 
        monto = Integer.parseInt(JOptionPane.showInputDialog(
                "Ingrese monto a retirar de la cuenta de " + c2.Titular_cuenta));
        c2.sacarDinero(monto);
 
        monto = Integer.parseInt(JOptionPane.showInputDialog(
                "Ingrese monto a retirar de la cuenta de " + c3.Titular_cuenta));
        c3.sacarDinero(monto);
    }
 
}
 


