package cuentabancaria;



import javax.swing.JOptionPane;
import java.util.Calendar;


public class Cuenta_Bancaria {

 public int No_cuenta;
    public String Titular_cuenta;
    public int Año_creacion;
    public double Saldo;
    public String Estado;

    // 🔹 Constructor
    public Cuenta_Bancaria(int No_cuenta, String Titular_cuenta, int Año_creacion, double Saldo, String Estado) {
        this.No_cuenta = No_cuenta;
        this.Titular_cuenta = Titular_cuenta;
        this.Año_creacion = Año_creacion;
        this.Saldo = Saldo;
        this.Estado = Estado;
    }

    public void mostrarInfo() {
        JOptionPane.showMessageDialog(null,
                "No de cuenta: " + No_cuenta + "\n"
                + "Titular de la cuenta: " + Titular_cuenta + "\n"
                + "Año de creación: " + Año_creacion + "\n"
                + "Saldo: $" + Saldo + "\n"
                + "Estado: " + Estado
        );
    }

    public boolean informacion() {
        int anioAc = Calendar.getInstance().get(Calendar.YEAR);
        System.out.println("Este es el año actual: " + anioAc);
        return (anioAc - Año_creacion) > 50;
    }

    public int antiguedad() {
        int anioAc = Calendar.getInstance().get(Calendar.YEAR);
        return anioAc - Año_creacion;
    }

    public void incrementarSaldo() {
        if (antiguedad() >= 5) {
            double incremento = Saldo * 0.05;
            Saldo += incremento;
            JOptionPane.showMessageDialog(null,
                    "La cuenta de " + Titular_cuenta + " recibió un incremento del 5%.\nNuevo saldo: " + Saldo);
        }
    }
//Metodo Sacar dinero 
    public void sacarDinero(int monto) {
        if (monto <= 0) {
            JOptionPane.showMessageDialog(null, "El monto a retirar debe ser mayor que cero.");
            return;
        }
        if (monto > Saldo) {
            JOptionPane.showMessageDialog(null, "Saldo insuficiente.\n"
                    + "Saldo actual: $" + Saldo + "\n" + "Intentó retirar: $" + monto);
        } else {
            Saldo -= monto;
            JOptionPane.showMessageDialog(null, "Retiro exitoso de $" + monto + "\n"
                    + "Nuevo saldo: $" + Saldo);
        }
    }

  
// 🔹 Comparar saldo entre tres cuentas
 public static void compararSaldos(Cuenta_Bancaria c1, Cuenta_Bancaria c2, Cuenta_Bancaria c3) {
        double s1 = c1.Saldo;
        double s2 = c2.Saldo;
        double s3 = c3.Saldo;

        double mayor = Math.max(s1, Math.max(s2, s3));
        String mensaje = "";

        if (mayor == s1) {
            mensaje = "La cuenta con mayor saldo es de " + c1.Titular_cuenta
                    + "\nSaldo: $" + s1
                    + "\nDiferencia con " + c2.Titular_cuenta + ": $" + (s1 - s2)
                    + "\nDiferencia con " + c3.Titular_cuenta + ": $" + (s1 - s3);
        } else if (mayor == s2) {
            mensaje = "La cuenta con mayor saldo es de " + c2.Titular_cuenta
                    + "\nSaldo: $" + s2
                    + "\nDiferencia con " + c1.Titular_cuenta + ": $" + (s2 - s1)
                    + "\nDiferencia con " + c3.Titular_cuenta + ": $" + (s2 - s3);
        } else {
            mensaje = "La cuenta con mayor saldo es de " + c3.Titular_cuenta
                    + "\nSaldo: $" + s3
                    + "\nDiferencia con " + c1.Titular_cuenta + ": $" + (s3 - s1)
                    + "\nDiferencia con " + c2.Titular_cuenta + ": $" + (s3 - s2);
        }

        JOptionPane.showMessageDialog(null, mensaje);
    }
}



