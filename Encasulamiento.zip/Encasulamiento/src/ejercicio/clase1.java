
package ejercicio;


public class clase1 {
     private String nombre;
    private String direccion;
    private int numero_estudiantes;
    private  int numero_salones;
    
    public clase1(String nombre, String direccion , int numero_estudiantes ,int numero_salones){
        this.nombre= nombre;
        this.direccion = direccion;
        this .numero_estudiantes= numero_estudiantes;
        this.numero_salones =numero_salones;
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getNumero_estudiantes() {
        return numero_estudiantes;
    }

    public void setNumero_estudiantes(int numero_estudiantes) {
        this.numero_estudiantes = numero_estudiantes;
    }

    public int getNumero_salones() {
        return numero_salones;
    }

    public void setNumero_salones(int numero_salones) {
        this.numero_salones = numero_salones;
    }

}
