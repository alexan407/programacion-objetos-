package ejercicio;

public class principal {
    
    public static void main(String[] args) {
      clase1 c1 = new clase1("coalamos", "Calle. 66 A No. 97 A-15", 300, 24);
        System.out.println("el nombre es ... " + c1.getNombre());
        System.out.println("la direccion es  ... " + c1.getDireccion());
        System.out.println("el numero de estudiantes es  ... " + c1.getNumero_estudiantes());
        System.out.println("el numero de salones es ... " + c1.getNumero_salones());
        c1.setNombre("coalamos");
        c1.setDireccion("Calle. 66 A No. 97 A-15");
        c1.setNumero_estudiantes(300);
        c1.setNumero_salones(24);
        
    }
    
}
