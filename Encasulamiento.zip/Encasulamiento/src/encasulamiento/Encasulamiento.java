
package encasulamiento;

public class Encasulamiento {

  
    public static void main(String[] args) {
       clase1 persona = new clase1("Juan ", 30000);
       // System.out.println("la persona es "+ persona.nombre);
        System.out.println("Su salario es"+ persona.nombre);
        System.out.println("Su salarie es"+persona.salario);
        //persona.nombre-"Luis";
        //System.out.println("Su salario es "+ persona.nombre);
        persona.cambiar();
    }
    
}
