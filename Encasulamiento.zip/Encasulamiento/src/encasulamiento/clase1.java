package encasulamiento;

public class clase1 {

    String nombre;
    static double salario;

    public clase1(String nombre, double salario) {

        this.nombre = nombre;
        this.salario = salario;

    }

    public void cambiar() {

        nombre = "Juannn";
        System.out.println("El nuevo nombre es....");
    }
}
