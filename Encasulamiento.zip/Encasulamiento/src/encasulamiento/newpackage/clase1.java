
package encasulamiento.newpackage;


public class clase1 {
    private int edad;
    private String nombre;
    
    public clase1(int edad,String nombre){
        this.edad=edad;
        this.nombre= nombre;
        
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
}
