
package encasulamiento.newpackage;


public class principal {

   
    public static void main(String[] args) {
       clase1  c1=new clase1(30,"Juan");
       System.out.println("el nombre es ... "+c1.getNombre());
       System.out.println("el nombre es ... "+c1.getEdad());
       c1.setEdad(50);
       System.out.println("el nombre es ... "+c1.getEdad());
       c1.setNombre("luis");
       System.out.println("el nombre es ... "+c1.getNombre());
       
    }
    
}
