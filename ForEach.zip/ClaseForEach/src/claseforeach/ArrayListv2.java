package claseforeach;

import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JOptionPane;

public class ArrayListv2 {
    public class ArrayListOrdenar {
 
  
  
    // Método para generar elementos en la lista
    public static void generar(ArrayList<String> obj, int x) {
        for (int i = 1; i <= x; i++) {
            String nombres = JOptionPane.showInputDialog("Ingrese Nombres y Apellidos");
            obj.add(nombres);
        }
    }

    // Método para imprimir elementos
    public static void imprimir(ArrayList<String> obj) {
        for (String elemento : obj) {
            System.out.println(elemento + " -");
        }
        System.out.println();
    }

    // Método para remover un elemento por índice
    public static void remover(ArrayList<String> obj, int y) {
        if (y >= 0 && y < obj.size()) {
            obj.remove(y);
        } else {
            System.out.println("Índice fuera de rango.");
        }
    }

    // Método para verificar si está vacío
    public static void estado(ArrayList<String> obj) {
        System.out.println("¿Está vacío?: " + obj.isEmpty());
    }

    // Main principal
    public static void main(String[] args) {
        ArrayList<String> obj1 = new ArrayList<>();

        int n = Integer.parseInt(JOptionPane.showInputDialog("Digite No. de elementos"));
        generar(obj1, n);

        System.out.println("Elementos del ArrayList:");
        imprimir(obj1);

        int ele = Integer.parseInt(JOptionPane.showInputDialog("Digite índice de elemento a remover"));
        remover(obj1, ele);

        System.out.println("Nueva Lista:");
        imprimir(obj1);

        int tam = obj1.size();
        System.out.println("Cantidad de elementos en la lista: " + tam);

        estado(obj1);

        // Ejemplo adicional: ordenar lista
        Collections.sort(obj1);
        System.out.println("Lista ordenada:");
        imprimir(obj1);
    }
}
}