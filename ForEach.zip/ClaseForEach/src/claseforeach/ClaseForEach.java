
package claseforeach;


public class ClaseForEach {

  
    public static void main(String[] args) {
       String[] tipoflores = {"Rose","Sunflower","Daisy","Dandelion","Violet","Lily"};
       
       //use a for loop to iterate through the array 
       for(int index=0;index < tipoflores.length; index++){
           System.out.println(tipoflores[index]);
          
       }// end for 
       // use a for  each to itierate throughthe array 
       for (String i :tipoflores){
           System.out.println(i);
       }//end for
    }
    
}
