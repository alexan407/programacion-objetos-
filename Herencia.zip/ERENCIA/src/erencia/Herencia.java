
package erencia;

import javax.swing.JOptionPane;

public class Herencia {

  
    public static void main(String[] args) {
    
        String placa = JOptionPane.showInputDialog("Digite placa");
        String ciudad = JOptionPane.showInputDialog("Digite ciudad");
        int modelo = Integer.parseInt(JOptionPane.showInputDialog("Digite modelo"));
        String color = JOptionPane.showInputDialog("Digite color");
    
}
}