package lista;

public class Alumno {

    private String Nombre;
    private String Apellido;
    private int curso;

    public Alumno(String Nombre, String Apellido, int curso) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.curso = curso;
    }

  

    @Override
    public String toString() {
        return "Alumnoclas{" + "Nombre=" + Nombre + ", Apellido=" + Apellido + ", curso=" + curso + '}';
    }

}
