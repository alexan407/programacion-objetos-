package lista;

import java.util.ArrayList;

public class Alumnomain {

    public static void main(String[] args) {
        ArrayList<Alumno> obj1 = new ArrayList<Alumno>(); // se instancia la clase ArrayList
        Alumno a1 = new Alumno("Juan", "Cely",101);
        Alumno a2 = new Alumno("Pedro", "Mancipe",102);
        Alumno a3 = new Alumno("Luis", "Motta",103);
        obj1.add(a1);
        obj1.add(a2);
        obj1.add(a3);

        for (int i = 0; i < obj1.size(); i++) {
            System.out.println("Estudiante " + (i + 1) + ": " + obj1.get(i));
        }
    }
}
