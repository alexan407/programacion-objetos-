
package newpackage;

import java.util.ArrayList;
import javax.swing.JOptionPane;
public class Principal {

    public static void main(String[] args) {
        
      ArrayList <Colegio> listaColegios = new ArrayList<>();
      int n = Integer.parseInt(JOptionPane.showInputDialog("¿Cuantos colegios desea registrar"));
      
      for (int i=0;i<n;i++){
          String nombre = JOptionPane.showInputDialog("Ingrese el nombre del colegio");
          String direccion =JOptionPane.showInputDialog("Ingrese la direccion del colegio");
       int numEstudiantes = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero de estudianres "));
       String rector =JOptionPane.showInputDialog("Ingrese el nombre del rector");
       
      // Mostrar todos los colegios usando el método mostrar()
        StringBuilder resultado = new StringBuilder("Lista de Colegios:\n\n");
        for (Colegio c : listaColegios) {
            resultado.append(c.mostrar()).append("\n");
        }
 
        JOptionPane.showMessageDialog(null, resultado.toString());
        System.out.println("Lista de Colegios:\n");
        for (Colegio c : listaColegios) {
            System.out.println(c.mostrar());
        }
        /*
        String resultado = "Lista de Colegios:\n\n";
            for (Colegio c : listaColegios) {
                resultado += c.mostrar() + "\n";
            }
       JOptionPane.showMessageDialog(null, resultado);*/
    }
}
}
