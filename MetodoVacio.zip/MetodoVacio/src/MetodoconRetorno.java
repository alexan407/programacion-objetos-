
import javax.swing.JOptionPane;

public class MetodoconRetorno {

    public String ProcesardorDatos(String apellidos, String nombres, String fechaNacimiento, double nota1, double nota2) {
        double promedio = (nota1 + nota2) / 2;

        String mensaje = "Datos del Estudiante:\n"
                + "Aapellidos: " + apellidos + "\n"
                + "Nombres :" + nombres + "\n"
                + "Fechade nacimiento:" + fechaNacimiento + "\n"
                + "Nota1: " + nota1 + "\n"
                + "Nota2: " + nota2 + "\n"
                + "Promedio: " + promedio;

        return mensaje;
    }

    public static void main(String[] args) {
        MetodoconRetorno dat = new MetodoconRetorno();

        String apellidos = JOptionPane.showInputDialog("Ingrese sus apellidos");
        String nombre = JOptionPane.showInputDialog("Ingrese sus nombre");
        String fechanacimiento = JOptionPane.showInputDialog("Ingresar su fecha de nacimiento (dd/mm/aa)");

        double nota1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la primera nota:"));
        double nota2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la segunda nota:"));

     String mensajeFinal = dat.ProcesardorDatos(apellidos, nombre, fechanacimiento, nota1, nota1);
        JOptionPane.showMessageDialog(null, mensajeFinal);
    }
}
