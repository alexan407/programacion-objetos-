
import javax.swing.JOptionPane;

public class MetodosArgumentos {

    public static void cuentas(String tit, int num, double sal) {
        System.out.println("Titular..." + tit + "...Numero cuenta..." + num + "\n..saldo.." + sal);
    }

    public static void main(String[] args) {
       // MetodosArgumentos met = new MetodosArgumentos();
        claseuno met = new claseuno();
        String titular = JOptionPane.showInputDialog("Ingrese Nombres del Titular");
        int ncuenta = Integer.parseInt(JOptionPane.showInputDialog("Ingrese No Cuenta"));
        double saldo = Double.parseDouble(JOptionPane.showInputDialog("Ingrese No Cuenta"));
        met.cuenta(titular, ncuenta, saldo);

        cuentas(titular, ncuenta, saldo);
    }

}
