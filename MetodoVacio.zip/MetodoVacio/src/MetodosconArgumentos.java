
import javax.swing.JOptionPane;


public class MetodosconArgumentos {
public void cuenta(String tit , int num, double sal){
    System.out.println("Titulas..."+tit+"...Numero cuenta.."+num+ "\n..saldo.."+sal);
    
}
public static void cuentas(String tit , int num, double sal){
    System.out.println("Titulas..."+tit+"...Numero cuenta.."+num+ "\n..saldo.."+sal);
    
}
    public static void main(String[] args) {
      MetodosconArgumentos met= new MetodosconArgumentos();
        String titular = JOptionPane.showInputDialog("Ingrese Nombres del Titular");
        int cuenta= Integer.parseInt(JOptionPane.showInputDialog("Ingrese No Cuenta"));
       double saldo = Double.parseDouble(JOptionPane.showInputDialog("Ingrese saldo de la cuenta"));
    met.cuenta(titular, cuenta, saldo);
    
    cuentas(titular,cuenta,saldo);
}
}
