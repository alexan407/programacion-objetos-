public class claseuno {
    
      public void cuenta(String tit, int num, double sal){
 
        System.out.println("Titular... "+tit+" ...Numero de Cuenta... "+num+"\n...Saldo... "+sal);
 
    }
}

