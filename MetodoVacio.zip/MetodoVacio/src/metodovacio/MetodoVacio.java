package metodovacio;

import javax.swing.JOptionPane;

public class MetodoVacio {

    public void datos() {
        String nombres = JOptionPane.showInputDialog("Ingresar Nombres del Empleado");
        String apellidos = JOptionPane.showInputDialog("Ingresar Apellido del Empleado");
        int edad=Integer.parseInt(JOptionPane.showInputDialog("Ingresar edad del Empleado"));
        double estatura = Double.parseDouble(JOptionPane.showInputDialog("Ingresar estatura del empleado"));
        
        System.out.println("Apellido..."+apellidos+"....Nombres..."+nombres+"\n..edad..."+edad+"...estatura..."+estatura);
    }

    public static void main(String[] args) {
MetodoVacio met=new MetodoVacio ();
met.datos();
    }

}
