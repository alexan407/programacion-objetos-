package vectordeobjetos;

public class VectordeObjetos {

    public static void main(String[] args) {
        colegio[] colegio = new colegio[3];

        colegio[0] = new colegio("Jose Celestino Mutis", "Carrera2 No4-01", 300);
        colegio[1] = new colegio("Santiago Felipe","Cra 27 sur # 40-21",200);
        colegio[2] = new colegio("Walt Wiltman","Ac 72 # 57 33",500);

        for(int i=0; i<colegio.length; i++){
            colegio[i].mostrarInfo();
    }
    }
}
