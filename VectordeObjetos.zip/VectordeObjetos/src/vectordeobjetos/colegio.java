package vectordeobjetos;

public class colegio {

    private String nombres;
    private String direccion;
    private int estudiantes;

    public colegio(String nombres, String direccion, int estudiantes) {
        this.nombres = nombres;
        this.direccion = direccion;
        this.estudiantes = estudiantes;
    }

    public void mostrarInfo() {
        System.out.println("Colegio" + nombres + "Direccion" + direccion + "Estudiabtes" + estudiantes);

}
}
