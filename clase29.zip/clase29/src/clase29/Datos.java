
package clase29;

public class Datos {
     int doc;
    String nombres ,apellidso,programas,facultades;

    public Datos(int doc, String nombres, String apellidso, String programas, String facultades) {
        this.doc = doc;
        this.nombres = nombres;
        this.apellidso = apellidso;
        this.programas = programas;
        this.facultades = facultades;
    }

    public int getDoc() {
        return doc;
    }

    public void setDoc(int doc) {
        this.doc = doc;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidso() {
        return apellidso;
    }

    public void setApellidso(String apellidso) {
        this.apellidso = apellidso;
    }

    public String getProgramas() {
        return programas;
    }

    public void setProgramas(String programas) {
        this.programas = programas;
    }

    public String getFacultades() {
        return facultades;
    }

    public void setFacultades(String facultades) {
        this.facultades = facultades;
    }
    
}
