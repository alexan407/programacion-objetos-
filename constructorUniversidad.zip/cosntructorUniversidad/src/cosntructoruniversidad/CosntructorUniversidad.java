package cosntructoruniversidad;

public class CosntructorUniversidad {

    public static void main(String[] args) {
        univesidad u1 = new univesidad("Jhon", 485785787, "Ingenieria de ssitemas", 3);
        univesidad u2 = new univesidad("Juan", 2858458, "Ingenieria de sistemas ", 3);
        u1.mostrarInfo();
        u2.mostrarInfo();
    }

}
