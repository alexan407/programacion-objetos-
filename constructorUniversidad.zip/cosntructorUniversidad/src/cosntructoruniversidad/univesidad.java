package cosntructoruniversidad;

public class univesidad {

    public String nombre;
    public int nit;
    public String carrera;
    public int semestre;

    public univesidad(String nombre, int nit, String carrera, double semestre) {
        this.nombre = nombre;
        this.nit = nit;
        this.carrera = carrera;
        this.semestre = (int) semestre;

    }

    public void mostrarInfo() {
        System.out.println("Nombre:" + nombre);
        System.out.println("Nit:" + nit);
        System.out.println("Carrera:" + carrera);
        System.out.println("semestre :" + semestre);
    }
}
