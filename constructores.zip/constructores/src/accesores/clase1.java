
package accesores;


public class clase1 {
    
    public String nombres;
    public String apellidos;
    public int edad;
    protected double salario;
    
   /*
    public void asignarsalario(){
    salario=15000;
    nombres="jhioasbd";
    }
   */ 
   
    
}
