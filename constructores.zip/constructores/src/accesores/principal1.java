package accesores;

public class principal1 {

    public static void main(String[] args) {
        clase1 p = new clase1();
        //asignar valores a los atributos publicos
        p.nombres = "Jhon Alexander";
        p.apellidos = "Casas Chillon";
        p.edad = 21;
        p.salario = 75000000;
    }

}

