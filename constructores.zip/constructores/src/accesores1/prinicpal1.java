package accesores1;

import accesores.clase1;

public class prinicpal1 {



    public static void main(String[] args) {
        clase1 p1 = new clase1() ;
            p1.apellidos="xxxx";
            
        }
    
    }
