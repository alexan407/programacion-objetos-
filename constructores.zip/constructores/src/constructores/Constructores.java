package constructores;

public class Constructores {

    public static void main(String[] args) {
        vehiculo v1 = new vehiculo("Toyota", 25025, "Rojo", 75000000);
        vehiculo v2 = new vehiculo("Renault", 25022, "Azul", 45000000);
        v1.mostrarInfo();
        v2.mostrarInfo();
    }

}
