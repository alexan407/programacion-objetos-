package constructores;

public class vehiculo {

    public String marca;
    public int modelo;
    public String color;
    public double valor;

    /*public vehiculo(String marcav, int modelov, String colorv, double valorv) {
        marca = marcav
        modelo = modelov
        color  = colorv
        valor = valorv
    }  */
    // constructor 
    public vehiculo(String marca, int modelo, String color, double valor) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.valor = valor;

    }

    //  metodo para mostrar informacion del vehiculo 
    public void mostrarInfo() {
        System.out.println("Marca:" + marca);
        System.out.println("Modelo:" + modelo);
        System.out.println("Color:" + color);
        System.out.println("Valor :$" + valor);
    }
}
