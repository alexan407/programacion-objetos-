package constructorlibro;

public class Constructorlibro {

    public static void main(String[] args) {

        libro libro1 = new libro("Cien años de la soledad", "Gabriel Garcia Marquez", 1967);
        libro libro2 = new libro("La sombra del viento", "Carlos Ruiz Zafon", 2001);
        libro1.mostrarInfo();
        libro2.mostrarInfo();

        System.out.println("Detalles del primer libro:");
        libro1.mostrarInfo();
        System.out.println("¿Es un clásico? " + (libro1.informacion() ? "Sí" : "No"));
        System.out.println("Antigüedad: " + libro1.antiguedad() + " años\n");

        System.out.println("Detalles del segundo libro:");
        libro2.mostrarInfo();
        System.out.println("¿Es un clásico? " + (libro2.informacion() ? "Sí" : "No"));
        System.out.println("Antigüedad: " + libro2.antiguedad() + " años");
    }
}
