package constructorlibro;
import java.util.Calendar;
public class libro {

    //atributos
    private String titulo;
    private String autor;
    private int publicado;

    //construcor que recibe parametros para inicializar los atributos
    public libro(String titulo, String autor, int publicado) {
        this.titulo = titulo;
        this.autor = autor;
        this.publicado = publicado;

     
    }
       public void mostrarInfo() {
        System.out.println("Titulo: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Ano publicado: " + publicado);
    }
        public boolean informacion() {
        int anioAc = Calendar.getInstance().get(Calendar.YEAR);
        System.out.println("Este es el anio actual: " + anioAc);
        return (anioAc - publicado) > 50;
    }
  public int antiguedad() {
        int anioAc = Calendar.getInstance().get(Calendar.YEAR);
        return anioAc - publicado;
    }
       
}
