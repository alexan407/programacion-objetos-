package ejercicio1;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Ejercicio1 {


    public void llenarVector(int[] vector, Scanner sc) {
        System.out.println("Ingrese los elementos del vector de tamaño " + vector.length + ":");
        for (int i = 0; i < vector.length; i++) {
            boolean valido = false;
            while (!valido) {
                try {
                    System.out.print("Elemento [" + i + "]: ");
                    vector[i] = sc.nextInt();
                    valido = true;
                } catch (InputMismatchException e) {
                    System.out.println("⚠ Error: Debe ingresar un número entero. Intente de nuevo.");
                    sc.nextLine();
                }
            }
        }
    }

    public void imprimirVector(int[] vector) {
        System.out.print("[ ");
        for (int i = 0; i < vector.length; i++) {
            System.out.print(vector[i] + " ");
        }
        System.out.println("]");
    }

    public void conectarVectores(int[] v1, int[] v2, int[] resultado) {
        int index = 0;

        if (v1.length < v2.length) {
            for (int i = 0; i < v1.length; i++) {
                resultado[index++] = v1[i];
            }
            for (int i = 0; i < v2.length; i++) {
                resultado[index++] = v2[i];
            }
        } else {
            for (int i = 0; i < v2.length; i++) {
                resultado[index++] = v2[i];
            }
            for (int i = 0; i < v1.length; i++) {
                resultado[index++] = v1[i];
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Ejercicio1 p = new Ejercicio1();

        int n1 = 0, n2 = 0;

      
        while (true) {
            try {
                System.out.print("Ingrese el tamaño del primer vector: ");
                n1 = sc.nextInt();
                if (n1 <= 0) {
                    throw new IllegalArgumentException("El tamaño debe ser mayor que 0.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número entero válido.");
                sc.nextLine(); 
            } catch (IllegalArgumentException e) {
                System.out.println(" " + e.getMessage());
            }
        }

        int[] vector1 = new int[n1];
        p.llenarVector(vector1, sc);

       
        while (true) {
            try {
                System.out.print("Ingrese el tamaño del segundo vector: ");
                n2 = sc.nextInt();
                if (n2 <= 0) {
                    throw new IllegalArgumentException("El tamaño debe ser mayor que 0.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println(" Error: Ingrese un número entero válido.");
                sc.nextLine();
            } catch (IllegalArgumentException e) {
                System.out.println(" " + e.getMessage());
            }
        }

        int[] vector2 = new int[n2];
        p.llenarVector(vector2, sc);

        int[] resultado = new int[vector1.length + vector2.length];
        p.conectarVectores(vector1, vector2, resultado);

     
        System.out.println("\nPrimer vector:");
        p.imprimirVector(vector1);

        System.out.println("Segundo vector:");
        p.imprimirVector(vector2);

        System.out.println("Vector resultante:");
        p.imprimirVector(resultado);

        sc.close();
    }
}