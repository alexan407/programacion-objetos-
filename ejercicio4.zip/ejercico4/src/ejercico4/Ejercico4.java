package ejercico4;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Ejercico4 {

    Scanner sc = new Scanner(System.in);
    String[] meses = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio"};
    int[] años = {2020, 2021, 2022, 2023, 2024, 2025};

   
    public void Ventas(int[][] ventas) {
        for (int i = 0; i < ventas.length; i++) {       // años
            for (int j = 0; j < ventas[i].length; j++) { // meses
              int valor = -1;
                while (true) {
                    try {
                        System.out.print("Ingrese ventas para " + meses[j] + " de " + años[i] + ": ");
                        valor = sc.nextInt();
                        if (valor < 0) {
                            System.out.println("⚠ No se permiten valores negativos. Intente de nuevo.");
                        } else {
                            break; // dato válido
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("⚠ Error: Debe ingresar un número entero válido.");
                        sc.nextLine(); // limpiar buffer
                    }
                }
                ventas[i][j] = valor;
            }
        }
    }

    
    public void sumatoriaPorMes(int[][] ventas, int[] sumaMeses) {
        for (int j = 0; j < ventas[0].length; j++) {
            int suma = 0;
            for (int i = 0; i < ventas.length; i++) {
                suma += ventas[i][j];
            }
            sumaMeses[j] = suma;
        }
    }


    public void sumatoriaPorAño(int[][] ventas, int[] sumaAños) {
        for (int i = 0; i < ventas.length; i++) {
            int suma = 0;
            for (int j = 0; j < ventas[i].length; j++) {
                suma += ventas[i][j];
            }
            sumaAños[i] = suma;
        }
    }

  
    public void imprimirVector(int[] vector, String tipo) {
        if (tipo.equals("mes")) {
            for (int j = 0; j < vector.length; j++) {
                System.out.println(meses[j] + ": " + vector[j]);
            }
        } else if (tipo.equals("año")) {
            for (int i = 0; i < vector.length; i++) {
                System.out.println(años[i] + ": " + vector[i]);
            }
        }
    }

    
    public void hallarMayorMenor(int[] sumaMeses, int[] sumaAños) {
      
        int minMes = sumaMeses[0], maxMes = sumaMeses[0];
        int posMinMes = 0, posMaxMes = 0;
        for (int j = 1; j < sumaMeses.length; j++) {
            if (sumaMeses[j] < minMes) {
                minMes = sumaMeses[j];
                posMinMes = j;
            }
            if (sumaMeses[j] > maxMes) {
                maxMes = sumaMeses[j];
                posMaxMes = j;
            }
        }

     
        int minAño = sumaAños[0], maxAño = sumaAños[0];
        int posMinAño = 0, posMaxAño = 0;
        for (int i = 1; i < sumaAños.length; i++) {
            if (sumaAños[i] < minAño) {
                minAño = sumaAños[i];
                posMinAño = i;
            }
            if (sumaAños[i] > maxAño) {
                maxAño = sumaAños[i];
                posMaxAño = i;
            }
        }

        System.out.println("\n📊 Resultados:");
        System.out.println("Mes con MENOS ventas: " + meses[posMinMes] + " con " + minMes);
        System.out.println("Mes con MÁS ventas: " + meses[posMaxMes] + " con " + maxMes);
        System.out.println("Año con MENOS ventas: " + años[posMinAño] + " con " + minAño);
        System.out.println("Año con MÁS ventas: " + años[posMaxAño] + " con " + maxAño);
    }

    public static void main(String[] args) {
 Ejercico4  c = new Ejercico4 (); 

        int[][] ventas = new int[6][6];   
        int[] sumaMeses = new int[6];
        int[] sumaAños = new int[6];

        
        c.Ventas(ventas);

      
        c.sumatoriaPorMes(ventas, sumaMeses);
        c.sumatoriaPorAño(ventas, sumaAños);

        
        System.out.println("\nSumatoria por MES:");
        c.imprimirVector(sumaMeses, "mes");

        System.out.println("\nSumatoria por AÑO:");
        c.imprimirVector(sumaAños, "año");

        
        c.hallarMayorMenor(sumaMeses, sumaAños);
    }
}
