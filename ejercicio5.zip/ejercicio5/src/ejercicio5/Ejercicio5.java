package ejercicio5;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.InputMismatchException;
public class Ejercicio5 {


 ArrayList<String> estudiantes = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    public void Estudiantes() {
           int n = 0;

        while (true) {
            try {
                System.out.print("Ingrese la cantidad de estudiantes: ");
                n = sc.nextInt();
                sc.nextLine(); 
                if (n <= 0) {
                    throw new IllegalArgumentException("La cantidad de estudiantes debe ser mayor que 0.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println(" Error: debe ingresar un número entero.");
                sc.nextLine(); 
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

 
        for (int i = 0; i < n; i++) {
            String nombre;
            while (true) {
                System.out.print("Nombre del estudiante " + (i + 1) + ": ");
                nombre = sc.nextLine().trim();

                if (nombre.isEmpty()) {
                    System.out.println(" El nombre no puede estar vacío. Intente de nuevo.");
                } else {
                    estudiantes.add(nombre);
                    break;
                }
            }
        }
    }


    public void ordenarPorLongitud() {
        for (int i = 0; i < estudiantes.size()-1; i++) {
            for (int j = i+1; j < estudiantes.size(); j++) {
                if (estudiantes.get(i).length() < estudiantes.get(j).length()) {
                    String temp = estudiantes.get(i);
                    estudiantes.set(i, estudiantes.get(j));
                    estudiantes.set(j, temp);
                }
            }
        }
    }

    public void mostrar() {
        System.out.println("\nEstudiantes ordenados (mayor a menor por longitud):");
        for (String nombre : estudiantes) {
            System.out.println(nombre + " (" + nombre.length() + " caracteres)");
        }
    }

    public static void main(String[] args) {
        Ejercicio5   ej = new Ejercicio5();
        ej.Estudiantes();
        ej.ordenarPorLongitud();
        ej.mostrar();
    }
}
    
   


