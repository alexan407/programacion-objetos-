package priemraclase;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Priemraclase {

    public static void main(String[] args) {
        Scanner in = new Scanner (System.in) ;
        int num;
        try {
        
        System.out.println("Ingresa un valor entero:");
        num=in.nextInt();
        int cuadrado =num * num ;
        System.out.println("el cuadradod e " + num + "es" + cuadrado);
        
                }catch (InputMismatchException ex) { // 
       System.out.println("Debe ingresar obligatoriamente un numero entero no ingrese letras");
               }
    }
    
}
