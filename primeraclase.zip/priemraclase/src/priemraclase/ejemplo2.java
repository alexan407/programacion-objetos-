
package priemraclase;

import java.util.InputMismatchException;
import java.util.Scanner;


public class ejemplo2 {
  public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        try {
            int num1, num2;
            System.out.println("Ingresa el primer valor (dividendo):");
            num1 = teclado.nextInt();
            System.out.println("Ingresa el segundo valor (divisor):");
            num2 = teclado.nextInt();

            int resu = num1 / num2;
            System.out.println("La división de " + num1 + " / " + num2 + " es " + resu);

        } catch (InputMismatchException ex) {
            System.out.println("Debe ingresar obligatoriamente números enteros. " + ex);
        } catch (ArithmeticException ex) {
            System.out.println("No se puede dividir entre cero. " + ex);
        } finally {
            teclado.close();
        }
    }
}
