package priemraclase;

public class ejemplo6 {
     public static void main(String[] args) {
        
         int []arr ={1,2,3};
         try{ 
             System.out.println(arr[5]);
         }catch(ArrayIndexOutOfBoundsException ex){
             System.out.println("El vector no contienen el elemneto 6");
             
         }
              finally { 
             // Este bloque siempre se ejecuta 
             System.out.println("el bloque finally siempre se eejecuta independientemente de ");
         }  
     }
}
