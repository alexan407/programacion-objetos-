package sobrecarga_metodos;

public class Sobrecarga_metodos {

    public static void main(String[] args) {
        clase1 c1 = new clase1();
        c1.sobecarga();
        c1.sobecarga(3000);
        c1.sobecarga(500, "Juan");
        c1.sobecarga(600, "Luis");
    }

}
