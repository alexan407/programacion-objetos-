
package sobrecarga_metodos;

public class clase1 {
   public void sobecarga(){
       System.out.println("Ejemplo de la sobre carga de metodos");
   }
   
   public void sobecarga(int sal ){
       System.out.println("Ejemplo de la sobre carga de metodos");
}
    public void sobecarga(int sal  ,String nombres){
       System.out.println("Ejemplo de la sobre carga de metodos");
}
       public void sobecarga(double sal ,String nombres){
       System.out.println("Ejemplo de la sobre carga de metodos");
}
}