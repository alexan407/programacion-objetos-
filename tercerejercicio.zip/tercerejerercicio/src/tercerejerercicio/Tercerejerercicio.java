package tercerejerercicio;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Tercerejerercicio {

    public void generar(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {          
            for (int j = 0; j < matriz[i].length; j++) {     
                matriz[i][j] = (i + j) % 2;
            }
        }
    }

 
    public void imprimir(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {           
            for (int j = 0; j < matriz[i].length; j++) {    
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(); 
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

Tercerejerercicio p = new Tercerejerercicio();

   int m =0 , n=0;
       while (true) {
            try {
                System.out.print("Ingrese número de filas (m): ");
                m = sc.nextInt();
                if (m <= 0) {
                    throw new IllegalArgumentException(" El número de filas debe ser mayor que 0.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Error: Debe ingresar un número entero válido.");
                sc.nextLine(); 
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

      
        while (true) {
            try {
                System.out.print("Ingrese número de columnas (n): ");
                n = sc.nextInt();
                if (n <= 0) {
                    throw new IllegalArgumentException(" El número de columnas debe ser mayor que 0.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println(" Error: Debe ingresar un número entero válido.");
                sc.nextLine(); 
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }


        int[][] matriz = new int[m][n];


        p.generar(matriz);
        System.out.println("\n Matriz alternada:");
        p.imprimir(matriz);
    }
}
